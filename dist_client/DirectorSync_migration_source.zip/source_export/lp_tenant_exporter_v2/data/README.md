# Data folder

This directory is intentionally empty in the handover package.

Place here the source LogPoint JSON dump(s) obtained from the customer environment, for example:

- `sync_config_ESA.json` — backend configuration dump
- `alerts_SH.json` — search-head alerts dump (optional)

These files contain customer data and must not be shared outside the target environment.
