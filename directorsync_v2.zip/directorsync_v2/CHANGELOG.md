# CHANGELOG.md
- 2025-09-27 v2.0.0 — Initial common trunk, repos importer implemented, strict CLI compatibility.
