# BUILD_EXE.md — auto-py-exe

1. Install auto-py-exe
2. Script Location: `lp_tenant_importer_v2/main.py`
3. Console Based
4. Include `.env` and `tenants.yml` alongside the executable (or use absolute paths).
5. Build
